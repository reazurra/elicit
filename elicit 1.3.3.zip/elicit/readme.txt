=== elicit ===
Theme Name: elicit
Theme URI: http://mizmizi.com/themes/elicit/
Author URI: http://mizmizi.com/
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
-------------------------------------------------------
elicit theme, Copyright 2015-2016 mizmizi.com
elicit WordPress theme is distributed under the terms of the GNU GPL
-------------------------------------------------------
== Description ==

elicit is seo friendly and faster loading WordPress theme , With popular posts, social sharing widget and nice slider also has five widget area which will give your site professional look. elicit is fit for, food, business, health, portfolio, travel, photography, design, personal and any other creative blogs and websites. elicit compatible with any browser and support on all major WordPress plugins. Be amazed how quickly you get your next website up and running.

== resources ==
FontAwesome Font Awesome 4.4.0 by @davegandy - http://fontawesome.io - @fontawesome License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
Bootstrap (http://getbootstrap.com/) licensed under MIT license (https://github.com/twbs/bootstrap/blob/master/LICENSE)
WP-Bootstrap-NavWalker licensed under the GPLv2 license (http://www.gnu.org/licenses/gpl-2.0.html)


Some images are created by mizmizi and Images Licensed under Creative Commons Zero (https://pixabay.com/en/)

Images used in Theme Screenshot:
https://pixabay.com/en/butterfly-nature-living-nature-734654/
https://pixabay.com/en/chocolate-dark-coffee-confiserie-183543/
https://pixabay.com/en/thailand-elephant-sunset-nature-142982/
https://pixabay.com/en/autumn-landscape-nature-golden-219972/


== Tags ==
Responsive layout, Featured images, Light, Blue, Black, Gray, White, Full width template, Custom background, Custom colors, Custom Header, Custom menu, Two Columns, Right sidebar, Threaded comments, Sticky post, Photoblogging


